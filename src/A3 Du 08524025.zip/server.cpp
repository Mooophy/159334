//159.334 - Networks
//single threaded server

//This Assignment was done in a Group
//This code was tested working with three fixed keys, and never
//the same key twice consecutively
//Tested encryption and decryption with no problems, aphabet capitials and lower case
//Numbers and spaces combind together

#include <stdio.h>
#include <winsock.h>
#include <stdlib.h>

#define WSVERS MAKEWORD(2,0)
WSADATA wsadata;

int k=0;			//The key selected
int prev=1;		//Has the key been used previously 0 is the current start key, previous set to key 1 to avoid mix up
int d,e,nn;		//The keys

int repeatSquare(int x,int e,int n);
void decryption (char *recieve,char *temp,int d,int n);

//*******************************************************************
//MAIN
//*******************************************************************
int main(int argc, char *argv[]) {
	
//********************************************************************
// INITIALIZATION
//********************************************************************
   struct sockaddr_in localaddr,remoteaddr;
   SOCKET s,ns;
   char send_buffer[80],receive_buffer[80],temp_buffer[80];
   int n,bytes,addrlen;
   memset(&localaddr,0,sizeof(localaddr));


//********************************************************************
// WSSTARTUP
//********************************************************************
   if (WSAStartup(WSVERS, &wsadata) != 0) {
      WSACleanup();
      printf("WSAStartup failed\n");
   }
//********************************************************************
//SOCKET
//********************************************************************

   s = socket(PF_INET, SOCK_STREAM, 0);
   if (s == INVALID_SOCKET) {
      printf("socket failed\n");
   }

   localaddr.sin_family = AF_INET;
   if (argc == 2) localaddr.sin_port = htons((u_short)atoi(argv[1]));
   else localaddr.sin_port = htons(1234);
   localaddr.sin_addr.s_addr = INADDR_ANY;
//********************************************************************
//BIND
//********************************************************************

   if (bind(s,(struct sockaddr *)(&localaddr),sizeof(localaddr)) == SOCKET_ERROR) {
      printf("Bind failed!\n");
   }
//********************************************************************
//LISTEN
//********************************************************************
   listen(s,5);
   
//********************************************************************
//INFINITE LOOP
//********************************************************************
   while (1) {
      addrlen = sizeof(remoteaddr);
//********************************************************************
//NEW SOCKET newsocket = accept
//********************************************************************
      ns = accept(s,(struct sockaddr *)(&remoteaddr),&addrlen);
      if (ns == INVALID_SOCKET) break;
      printf("connected to      %s at port %d \n",inet_ntoa(remoteaddr.sin_addr),ntohs(localaddr.sin_port));
		while (k==prev)	//If the current key selected = the previous key random number generate between 0 - 2
		{
			k=rand()%3;
		}
		if (k==0)
		{
			e=17,d=13,nn=253;		//Different sets of keys
			printf("Key 1 Selected: e=17, d=13, n=253\n");
		}
		if (k==1)
		{
			e=7,d=63,nn=253;
			printf("Key 2 Selected: e=7, d=43, n=77\n");
		}
		if (k==2)
		{
			e=7,d=283,nn=253;
			printf("Key 3 Selected: e=17, d=53, n=77\n");
		}
		prev=k;					//Updates the previous key to current
		sprintf(send_buffer,"Key %d %d \r\n",e, nn);
		bytes = send(ns, send_buffer, strlen(send_buffer), 0);	//Send the public key to the client
		if (bytes == SOCKET_ERROR) break;
      while (1) {
         n = 0;
         while (1) {
//********************************************************************
//RECEIVE
//********************************************************************
            bytes = recv(ns, &receive_buffer[n], 1, 0);
//********************************************************************
//PROCESS REQUEST
//********************************************************************
            if ((bytes == SOCKET_ERROR) || (bytes == 0)) break;		//gets rid of \r\n
            if (receive_buffer[n] == '\n') { /*end on a LF*/
               receive_buffer[n] = '\0';
               break;
            }
            if (receive_buffer[n] != '\r') n++; /*ignore CRs*/
         }
         if ((bytes == SOCKET_ERROR) || (bytes == 0)) break;
//********************************************************************
//Decryption
//********************************************************************
			printf("///////////////////////////////////////////////////////\n");		//received new message
			printf("The original message was: %s\n",receive_buffer);		//Prints out the encrypted message
			memset(temp_buffer,0,sizeof(temp_buffer));						//Clears out the temp buffer for a new decryted message to be place inside
			decryption(receive_buffer,temp_buffer,d,nn);						//Decrypts the message with private key
         sprintf(send_buffer, "The client typed '%s' - There are %d bytes of information\r\n", temp_buffer, n);	//Send what was received after decryption
         printf("The decrypted message is: %s\n",temp_buffer);			//Prints out the decrypted message
//********************************************************************
//SEND
//********************************************************************
         bytes = send(ns, send_buffer, strlen(send_buffer), 0);
         if (bytes == SOCKET_ERROR) break;
      }
//********************************************************************
//CLOSE SOCKET
//********************************************************************
      closesocket(ns);
      printf("disconnected from %s\n",inet_ntoa(remoteaddr.sin_addr));
   }
   closesocket(s);
   return 0;
}

int repeatSquare(int x,int en,int n)
{
	int y=1;//initialize y to 1, very important
	while (en>0){
		if (( en % 2 )== 0){
			x = (x*x) % n;
			en = en/2;
		}
		else {
			y = (x*y) % n;
			en = en-1;
		}
	}
	return y;// the result is stored in y
}

void decryption (char *receive,char *temp,int dn,int n)		//The decryption algorithm
{
	int i=0;
	int length;
	int input;
	int result;
	length=strlen(receive);
	for(i=0;i<length;i++)		//For every character of the string
	{
		input=(int) receive[i];	//Put it in as an int
		if (input<0)				//encrypted values that are greater than 126 will show up as negative
		{								//Basically -256 + what was the positive value
			input = input + 256;	//This is fixed by adding 256 to that value to get the original
		}
		//printf("Input character value: %d/",input);	//Testing Purposes
		result=repeatSquare(input,dn,n);	//Decrypts the int value
		//printf("D is: %d,N is: %d", dn,n);				//Testing Purposes
		temp[i]=(char) result;	//int value is then put in the temp buffer as a character
		//printf("Decrypted character value: %d\n", result);	//Testing Purposes
	}
}
