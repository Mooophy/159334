//159.334 - Networks
//	CLIENT

//This Assignment was done in a Group
//This code was tested working with three fixed keys, and never
//the same key twice consecutively
//Tested encryption and decryption with no problems, aphabet capitials and lower case
//Numbers and spaces combind together

#include <stdio.h>
#include <stdlib.h>
#include <winsock.h>

#define WSVERS MAKEWORD(2,0)
WSADATA wsadata;

int e,nn,d=13;		//The keys, d is present here for testing purposes not part of the code
int repeatSquare(int x,int e,int n);	//repeat Square for finding the remainder
void encryption(char *temp, char *send, int e, int n);
void decryption (char *send,char *temp,int d,int n);
//char *sendbuf;

int main(int argc, char *argv[]) {
//*******************************************************************
// Initialization
// What are the important data structures?
//*******************************************************************
   struct sockaddr_in sin;
   struct hostent *h;
   SOCKET s;
   char send_buffer[80],receive_buffer[80],temp_buffer[80],temp1_buffer[80];
   int n,bytes;
   memset(&sin, 0, sizeof(sin));

//*******************************************************************
//WSASTARTUP 
//*******************************************************************

   if (WSAStartup(WSVERS, &wsadata) != 0) {
      WSACleanup();
      printf("WSAStartup failed\n");
   	exit(1);
   }

//*******************************************************************
//	Dealing with user's arguments
//*******************************************************************
 
   if (argc == 1) {
      printf("USAGE: client IP-address [port]\n"); //missing IP address
      exit(1);
   }
	
	//if there are 3 elements passed to the argv[] array.
   if (argc == 3) 
		sin.sin_port = htons((u_short)atoi(argv[2])); //get Remote Port number
   else 
		sin.sin_port = htons(1234); //use default port number

//*******************************************************************
//CREATE CLIENT'S SOCKET 
//*******************************************************************
   s = socket(PF_INET, SOCK_STREAM, 0);
   if (s == INVALID_SOCKET) {
      printf("socket failed\n");
   	exit(1);
   }

   sin.sin_family = AF_INET;
//*******************************************************************
//GETHOSTBYNAME
//*******************************************************************
   if ((h=gethostbyname(argv[1])) != NULL) {
      memcpy(&sin.sin_addr,h->h_addr,h->h_length); //get remote IP address
   } else if ((sin.sin_addr.s_addr = inet_addr(argv[1])) == INADDR_NONE) {
      printf("An error occured when trying to translate to IP address\n");
   	exit(1);
   }
//*******************************************************************
//CONNECT
//*******************************************************************
   if (connect(s, (struct sockaddr *)&sin, sizeof(sin)) != 0) {
      printf("connect failed\n");
   	exit(1);
   }
	//*******************************************************************
//Main Program Start
//*******************************************************************
		memset (temp_buffer, 0, sizeof(temp_buffer));	//Clear all the buffers of data
		memset (send_buffer, 0, sizeof(send_buffer));
		memset (receive_buffer, 0, sizeof(receive_buffer));
//*******************************************************************
//Recieve Key
//*******************************************************************
		n=0;
		int key=0;
		while (key==0)		//After socket connection keep looping until receive the key from server
		{
			Sleep(1);
			while(1)
			{
				bytes = recv(s, &receive_buffer[n], 1, 0);
				//if ((bytes == SOCKET_ERROR) || (bytes == 0)) {
					//printf("recv failed\n");
					//exit(1);
				//}
				if (receive_buffer[n] == '\n') {  /*end on a LF*/
					receive_buffer[n] = '\0';
					break;
				}
				if (receive_buffer[n] != '\r') n++;   /*ignore CR's*/
			}
			printf("RECEIVED --> %s \n",receive_buffer);
			if (strncmp(receive_buffer,"Key",3)==0)
			{
				sscanf(receive_buffer, "Key %d %d",&e, &nn);
				printf("Public Key Recieved e:%d, n:%d\n",e, nn);
				key=1;		//Found the key and retrieve the key
			}
		}
//*******************************************************************
//While loop repeat
//*******************************************************************
	while(1)
	{
		printf("/////////////////////////////////////////////////////////////////\n");
		printf("Input message here: ");	//Inputs the message
		memset (temp_buffer, 0, sizeof(temp_buffer));
		memset (send_buffer, 0, sizeof(send_buffer));	//Clear the buffers
		gets(temp_buffer);
		encryption(temp_buffer,send_buffer,e,nn);			//Do the encryption
		//decryption(send_buffer,temp1_buffer,13,nn);	//Decrypt itself for testing
		printf("Encrypted: %s\n",send_buffer);				//Show the message after encryption
		strcat(send_buffer,"\r\n");
//*******************************************************************
//SEND
//*******************************************************************
		bytes = send(s, send_buffer, strlen(send_buffer),0);	//Message is sent in a packet
		if (bytes == SOCKET_ERROR) {
			printf("send failed\n");
			exit(1);
		}
		n = 0;
		while (1) {
//*******************************************************************
//RECEIVE
//*******************************************************************
			bytes = recv(s, &receive_buffer[n], 1, 0);
			if ((bytes == SOCKET_ERROR) || (bytes == 0)) {
				printf("recv failed\n");
				exit(1);
			}
			if (receive_buffer[n] == '\n') {  /*end on a LF*/
				receive_buffer[n] = '\0';
				break;
			}
			if (receive_buffer[n] != '\r') n++;   /*ignore CR's*/
		}
		printf("%s\n",receive_buffer);
		//gets(send_buffer);
	}
//*******************************************************************
//CLOSESOCKET   
//*******************************************************************
   closesocket(s);
   return 0;
}

int repeatSquare(int x,int en,int n)
{
	int y=1;//initialize y to 1, very important
	while (en>0){
		if (( en % 2 )== 0){
			x = (x*x) % n;
			en = en/2;
		}
		else {
			y = (x*y) % n;
			en = en-1;
		}
	}
	return y;// the result is stored in y
}

void encryption (char *temp,char *send,int en,int n)		//The encryption algorithm
{
	int i=0;
	unsigned int input;
	unsigned int result;
	int length;
	length=strlen(temp);
	for(i=0;i<length;i++)		//Takes every character in the string
	{
		input= (int) temp[i];	//Uses the decimal value of the character
		//printf("Input character value: %d/",input);		//Testing
		result=repeatSquare(input,en,n);		//Encrypts the decimal value
		send[i]=(char) result;		//Puts it back as a character and stores it in the send buffer
		//printf("Sent character value: %d\n", result);		//Testing
	}
}

void decryption (char *send,char *temp,int dn,int n)
{
	int i=0;
	int input;
	int result;
	int length;
	length=strlen(send);
	for(i=0;i<length;i++)
	{
		input= (int) send[i];
		if(input<0);
		{
			input=input+256;
		}
		printf("Input character value: %d/",input);
		result=repeatSquare(input,dn,n);
		temp[i]=(char) result;
		printf("Sent character value: %d\n", result);
	}
}
